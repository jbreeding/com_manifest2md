DROP TABLE IF EXISTS `#__manifest2md_extensions`;

DELETE FROM `#__content_types` WHERE (type_alias LIKE 'com_manifest2md.%');