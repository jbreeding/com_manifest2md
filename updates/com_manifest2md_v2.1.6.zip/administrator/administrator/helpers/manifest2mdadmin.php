<?php

/**
 * @version    CVS: 2.1.1
 * @package    Com_Manifest2md
 * @author     Emmanuel Lecoester <elecoest@gmail.com>
 * @author     Marc Letouzé <marc.letouze@liubov.net>
 * @license    GNU General Public License version 2 ou version ultérieure ; Voir LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

/**
 * Manifest2md helper.
 *
 * @since  1.6
 */
class Manifest2mdHelpersManifest2mdadmin
{
    /**
     * Configure the Linkbar.
     *
     * @param   string $vName string
     *
     * @return void
     */
    public static function addSubmenu($vName = '')
    {
        JHtmlSidebar::addEntry(
            JText::_('COM_MANIFEST2MD_TITLE_EXTENSIONS'),
            'index.php?option=com_manifest2md&view=extensions',
            $vName == 'extensions'
        );

        JHtmlSidebar::addEntry(
            JText::_('JCATEGORIES') . ' (' . JText::_('COM_MANIFEST2MD_TITLE_EXTENSIONS') . ')',
            "index.php?option=com_categories&extension=com_manifest2md",
            $vName == 'categories'
        );
        if ($vName == 'categories') {
            JToolBarHelper::title('Joomla Manifest To MarkDown: JCATEGORIES (COM_MANIFEST2MD_TITLE_EXTENSIONS)');
        }

    }

    /**
     * Gets the files attached to an item
     *
     * @param   int $pk The item's id
     *
     * @param   string $table The table's name
     *
     * @param   string $field The field's name
     *
     * @return  array  The files
     */
    public static function getFiles($pk, $table, $field)
    {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $query
            ->select($field)
            ->from($table)
            ->where('id = ' . (int)$pk);

        $db->setQuery($query);

        return explode(',', $db->loadResult());
    }

    /**
     * Gets a list of the actions that can be performed.
     *
     * @return    JObject
     *
     * @since    1.6
     */
    public static function getActions()
    {
        $user = JFactory::getUser();
        $result = new JObject;

        $assetName = 'com_manifest2md';

        $actions = array(
            'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
        );

        foreach ($actions as $action) {
            $result->set($action, $user->authorise($action, $assetName));
        }

        return $result;
    }
}
